package com.demo.ani.quickactionmenu.quickaction;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

public class QuickActionItem {
	
	private Drawable icon;
	private Bitmap thumb;
	private String title;
	private int actionId = -1;
    private boolean selected;
    private String tag;
    
	public QuickActionItem(int actionId, String title, Drawable icon, String tag) {
        this.title = title;
        this.icon = icon;
        this.actionId = actionId;
        this.tag = tag;
    }
    
    public void setTitle(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setIcon(Drawable icon) {
		this.icon = icon;
	}
	
	public Drawable getIcon() {
		return this.icon;
	}
	
	public void setActionId(int actionId) {
        this.actionId = actionId;
    }
	
	public int getActionId() {
        return this.actionId;
    }
	
	public void setActionId(String tag) {
        this.tag = tag;
    }
	
	public String getActionTag() {
        return this.tag;
    }
	
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	
	public boolean isSelected() {
		return this.selected;
	}
	
	public void setThumb(Bitmap thumb) {
		this.thumb = thumb;
	}
	
	public Bitmap getThumb() {
		return this.thumb;
	}

}
