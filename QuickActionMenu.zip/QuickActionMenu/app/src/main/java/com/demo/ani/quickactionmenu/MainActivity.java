package com.demo.ani.quickactionmenu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.demo.ani.quickactionmenu.quickaction.QuickActionBar;

public class MainActivity extends AppCompatActivity implements QuickActionBar.OnActionItemClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ImageView demoImage = (ImageView) findViewById(R.id.image);
        demoImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                QuickActionBar mQuickActionBar = new QuickActionBar(MainActivity.this);
                mQuickActionBar.addActionItem("TestData", 1, MainActivity.this);
                mQuickActionBar.show(demoImage);
            }
        });
    }

    @Override
    public void onItemClick(int requestType) {

    }
}
