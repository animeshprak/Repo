package com.demo.ani.quickactionmenu.quickaction;

import android.content.Context;
import android.graphics.Rect;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;


import com.demo.ani.quickactionmenu.R;

import java.util.ArrayList;
import java.util.List;

/**
 * QuickActionBar dialog.
 * 
 * @author Lorensius W. L. T <lorenz@londatiga.net>
 * 
 * Contributors:
 * - Kevin Peck <kevinwpeck@gmail.com>
 */

public class QuickActionBar extends QuickActionPopupWindow implements OnDismissListener {
	private ImageView mArrowUp;
	private ImageView mArrowDown;
	private LayoutInflater inflater;
	private ViewGroup mTrack;
	private OnActionItemClickListener mItemClickListener;
	private OnDismissListener mDismissListener;
	private Animation mTrackAnim;
	
	private List<QuickActionItem> mActionItemList = new ArrayList<QuickActionItem>();
	
	private boolean mDidAction;
	private Context _context;
	private int mChildPos;
	
	public QuickActionBar(Context context) {
		super(context);
		
		this._context = context;
		inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		//mTrackAnim = AnimationUtils.loadAnimation(context, R.anim.right_to_left);
		
		/*mTrackAnim.setInterpolator(new Interpolator() {
			public float getInterpolation(float t) {
				final float inner = (t * 1.55f) - 1.1f;
				return 1.2f - inner * inner;
			}
		});*/
		setRootViewId(R.layout.quickactionbar);
		
		mChildPos = 0;
	}
	
    public QuickActionItem getActionItem(int index) {
        return mActionItemList.get(index);
    }
    
	public void setRootViewId(int id) {
		mRootView =  inflater.inflate(id, null, false);
		mTrack = (ViewGroup) mRootView.findViewById(R.id.quick_action_item_container);

		mArrowDown = (ImageView) mRootView.findViewById(R.id.quick_action_arrow_down);
		mArrowUp = (ImageView) mRootView.findViewById(R.id.quick_action_arrow_up);

		mRootView.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		
		setContentView(mRootView);
	}

	public void addActionItem(String s, final int requestType, OnActionItemClickListener mClickListener) {
		this.mItemClickListener = mClickListener;
		TextView text = (TextView) mTrack.findViewById(R.id.quick_action_item_title);
		text.setText(s);
		text.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				if (mItemClickListener != null) {
					mItemClickListener.onItemClick(requestType);
                    dismiss();
				}
			};
		});
		//mTrack.setFocusable(true);
		//mTrack.setClickable(true);
	}
	
	/*public void addActionItem(QuickActionItem action) {
		//mActionItemList.add(action);
		
		//String title = action.getTitle();
		//Drawable icon = action.getIcon();
		
		//View container = (View) inflater.inflate(R.layout.quick_action_item, null);
		
		//container.setTag(action.getActionTag());
		ProgressBar img = (ProgressBar) mTrack.findViewById(R.id.quick_action_item_icon);
		img.setProgress(2);
		TextView text = (TextView) mTrack.findViewById(R.id.quick_action_item_title);
		
		//final int pos = mChildPos;
		//final int actionId = action.getActionId();
		
		*//*container.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mItemClickListener != null) {
                    mItemClickListener.onItemClick(QuickActionBar.this, pos, actionId);
                }

				mDidAction = true;
            	v.post(new Runnable() {
                    @Override
                    public void run() {
                        dismiss();
                    }
                });
			}
		});*//*

		mTrack.setFocusable(true);
		mTrack.setClickable(true);
		*//*mTrack.addView(mTrack, mChildPos);
		((LinearLayout)mTrack).setGravity(Gravity.CENTER);
		mChildPos++;*//*
	}*/
	
	public void setOnActionItemClickListener(OnActionItemClickListener listener) {
		mItemClickListener = listener;
	}
	
	public void show (View anchor) {
		preShow();

		int[] location = new int[2];
		
		mDidAction = false;
		
		anchor.getLocationOnScreen(location);

		Rect anchorRect = new Rect(location[0], location[1], location[0] + anchor.getWidth(), location[1]
		                	+ anchor.getHeight());

		mRootView.measure(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		
		int rootWidth = mRootView.getMeasuredWidth();
		int rootHeight = mRootView.getMeasuredHeight();

		int screenWidth = mWindowManager.getDefaultDisplay().getWidth();
		int screenHeight = mWindowManager.getDefaultDisplay().getHeight();
		
		int xPos = (screenWidth - rootWidth) / 2;
		int yPos = anchorRect.bottom;

		boolean onTop		= false;
		if((screenHeight - yPos) < rootHeight) {
			onTop = true;
			yPos = anchorRect.top - rootHeight;
		}
		
		showArrow(((onTop) ? R.id.quick_action_arrow_down : R.id.quick_action_arrow_up), anchorRect.centerX());
	
		mWindow.showAtLocation(anchor, Gravity.NO_GRAVITY, xPos, yPos);
		
	}
	
	private void showArrow(int whichArrow, int requestedX) {
        final View showArrow = (whichArrow == R.id.quick_action_arrow_up) ? mArrowUp : mArrowDown;
        final View hideArrow = (whichArrow == R.id.quick_action_arrow_up) ? mArrowDown : mArrowUp;

        final int arrowWidth = mArrowUp.getMeasuredWidth();

        showArrow.setVisibility(View.VISIBLE);
        
        ViewGroup.MarginLayoutParams param = (ViewGroup.MarginLayoutParams)showArrow.getLayoutParams();
        
        param.leftMargin = requestedX - arrowWidth / 2;
      
        hideArrow.setVisibility(View.INVISIBLE);
    }
	
	public void showViewItem(String tag) {
		View itemView = mTrack.findViewWithTag(tag);
		if(itemView != null) {
			itemView.setVisibility(View.VISIBLE);
		}
	}
	
	public void hideViewItem(String tag) {
		View itemView = mTrack.findViewWithTag(tag);
		if(itemView != null) {
			itemView.setVisibility(View.GONE);
		}
	}
	
	public void setOnDismissListener(QuickActionBar.OnDismissListener listener) {
		setOnDismissListener(this);
		
		mDismissListener = listener;
	}
	
	@Override
	public void onDismiss() {
		if (!mDidAction && mDismissListener != null) {
			mDismissListener.onDismiss();
		}
	}
	
	public interface OnActionItemClickListener {
		void onItemClick(int requestType);
	}
	
	public interface OnDismissListener {
		public abstract void onDismiss();
	}
}